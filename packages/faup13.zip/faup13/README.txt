Faup is a URL parser that you can download from http://www.github.com/stricaud/faup/

This is the WIN32 version.

To use smoothly:

Copy mozilla.tlds into C:\Program Files (x86)\faup-project/share/faup

If you cannot do that, you can use the env. variable FAUP_DATA_DIR to point to the dir where this file is.

FAUP_DATA_DIR=. faup.exe
